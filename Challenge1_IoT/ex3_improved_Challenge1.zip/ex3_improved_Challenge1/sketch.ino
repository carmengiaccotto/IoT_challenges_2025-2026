#include <WiFi.h>
#include <esp_now.h>
#include <math.h>

// Define pin connections for the sensors
#define PIR_PIN 13
#define LDR_PIN 34

// Broadcast MAC address for the SINK node (FF:FF:FF:FF:FF:FF)
uint8_t broadcastAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// Deep Sleep configuration
#define uS_TO_S_FACTOR 1000000ULL 
// Deep Sleep duration calculated based on Carmen Giaccotto's person code (X = 4.2 seconds)
uint64_t TIME_TO_SLEEP = 4200000ULL; 

// LDR Characteristics for Lux conversion (Standard Wokwi photoresistor)
const float GAMMA = 0.7;
const float RL10 = 50;

esp_now_peer_info_t peerInfo;

// OPTIMIZATION 1: Event-Driven Logic using RTC Memory
// These variables retain the previous sensor state during Deep Sleep on physical hardware.
RTC_DATA_ATTR int lastMotionState = -1; 
RTC_DATA_ATTR int lastLux = -1;

void setup() {
  Serial.begin(115200);
  delay(100);

  // 1. Initialize sensor pins
  pinMode(PIR_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);

  // 2. Read current sensor values
  int currentMotionState = digitalRead(PIR_PIN);
  int currentADC = analogRead(LDR_PIN); 

  // Convert raw ADC value to LUX
  float voltage = currentADC / 4095.0 * 3.3;
  if (voltage >= 3.3) voltage = 3.299;
  float resistance = 10000 * voltage / (3.3 - voltage);
  int currentLux = pow(RL10 * 1e3 * pow(10, GAMMA) / resistance, (1 / GAMMA));

  // 3. Evaluate if the environmental state has significantly changed
  bool firstBoot = (lastMotionState == -1);
  bool motionChanged = (currentMotionState != lastMotionState);
  // Ignore minor luminosity fluctuations (less than 50 LUX) to prevent useless transmissions
  bool luminosityChanged = (abs(currentLux - lastLux) > 50);

  // If this is not the first boot AND nothing significant changed, go back to sleep immediately
  if (!firstBoot && !motionChanged && !luminosityChanged) {
    Serial.println("State unchanged. Skipping Wi-Fi to save energy and returning to sleep.");
    Serial.flush();
    esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP);
    esp_deep_sleep_start();
  }

  // 4. State changed! Update the RTC variables for the next cycle
  lastMotionState = currentMotionState;
  lastLux = currentLux;

  // 5. Format the data string according to project specifications
  String message = "";
  if (currentMotionState == HIGH) {
    message = "MOTION_DETECTED-LUMINOSITY:" + String(currentLux);
  } else {
    message = "MOTION_NOT_DETECTED-LUMINOSITY:" + String(currentLux);
  }
  
  Serial.println("State changed. Generated message: " + message);

  // 6. Initialize Wi-Fi in Station mode (required for ESP-NOW)
  WiFi.mode(WIFI_STA);
  
  // OPTIMIZATION 2: Reduce TX Power to 2dBm to lower peak consumption
  WiFi.setTxPower(WIFI_POWER_2dBm);

  // 7. Initialize ESP-NOW protocol
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // 8. Register the peer (SINK node)
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("Failed to add peer");
    return;
  }

  // 9. Transmit the message via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *)message.c_str(), message.length());
   
  if (result == ESP_OK) {
    Serial.println("Message sent successfully (Optimized TX Power).");
  } else {
    Serial.println("Error sending the message.");
  }

  // 10. Enter Deep Sleep
  // A small delay ensures the physical radio finishes transmitting before power is cut
  delay(10);
  Serial.flush(); 
  esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP);
  esp_deep_sleep_start();
}

void loop() {
  // The loop is left empty because the ESP32 restarts from setup() 
  // every time it wakes up from Deep Sleep.
}