#include <WiFi.h>
#include <esp_now.h>
#include <math.h>

// Define pin connections for the sensors
#define PIR_PIN 13
#define LDR_PIN 34

// Broadcast MAC address for the SINK node (FF:FF:FF:FF:FF:FF)
uint8_t broadcastAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// Deep Sleep configuration
#define uS_TO_S_FACTOR 1000000ULL // Conversion factor from microseconds to seconds
// Deep Sleep duration calculated based on Carmen Giaccotto's person code (X = 4.2 seconds)
uint64_t TIME_TO_SLEEP = 4200000ULL; 

// LDR Characteristics for Lux conversion (Standard Wokwi photoresistor)
const float GAMMA = 0.7;
const float RL10 = 50;

esp_now_peer_info_t peerInfo;

void setup() {
  // Initialize serial communication at 115200 baud rate
  Serial.begin(115200);
  delay(100);

  // 1. Initialize sensor pins
  pinMode(PIR_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);

  // 2. Read sensor values
  int motionStatus = digitalRead(PIR_PIN);
  int rawLuminosity = analogRead(LDR_PIN); // Returns a value between 0 and 4095 on ESP32

  // LUX CONVERSION
  float voltage = rawLuminosity / 4095.0 * 3.3;
  if (voltage >= 3.3) voltage = 3.299;
  float resistance = 10000 * voltage / (3.3 - voltage);
  int luminosityLux = pow(RL10 * 1e3 * pow(10, GAMMA) / resistance, (1 / GAMMA));

  // 3. Format the data string
  String message = "";
  if (motionStatus == HIGH) {
    message = "MOTION_DETECTED-LUMINOSITY:" + String(luminosityLux);
  } else {
    message = "MOTION_NOT_DETECTED-LUMINOSITY:" + String(luminosityLux);
  }
  
  Serial.println("Generated message: " + message);

  // 4. Initialize Wi-Fi in Station mode
  WiFi.mode(WIFI_STA);

  // 5. Initialize ESP-NOW protocol
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }

  // 6. Register the peer (SINK node)
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  if (esp_now_add_peer(&peerInfo) != ESP_OK) {
    Serial.println("Failed to add peer");
    return;
  }

  // 7. Transmit the message via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *)message.c_str(), message.length());
   
  if (result == ESP_OK) {
    Serial.println("Message sent successfully.");
  } else {
    Serial.println("Error sending the message.");
  }

  // 8. Enter Deep Sleep
  Serial.println("Entering Deep Sleep for 4.2 seconds...");
  Serial.flush(); // Ensure all serial data is printed before sleeping
  esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP);
  esp_deep_sleep_start();
}

void loop() {
  // The loop is left empty because the ESP32 restarts from setup() 
  // every time it wakes up from Deep Sleep.
}