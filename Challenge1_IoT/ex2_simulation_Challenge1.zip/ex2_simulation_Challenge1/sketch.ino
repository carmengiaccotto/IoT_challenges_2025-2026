#include <WiFi.h>
#include <esp_now.h>
#include <math.h>

// Define pin connections for the sensors
#define PIR_PIN 13
#define LDR_PIN 34

// Broadcast MAC address for the SINK node (FF:FF:FF:FF:FF:FF)
uint8_t broadcastAddress[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// Deep Sleep configuration
#define uS_TO_S_FACTOR 1000000ULL // Conversion factor from microseconds to seconds
// Deep Sleep duration calculated based on Carmen Giaccotto's person code (X = 4.2 seconds)
uint64_t TIME_TO_SLEEP = 4200000ULL; 

// LDR Characteristics for Lux conversion (Standard Wokwi photoresistor)
const float GAMMA = 0.7;
const float RL10 = 50;

esp_now_peer_info_t peerInfo;

void setup() {
  // Initialize serial communication at 115200 baud rate
  Serial.begin(115200);
  delay(100);

  // START TIMING MEASUREMENTS
  // Record the start of the active phase
  unsigned long time_start_active = micros(); 

  // Initialize sensor pins
  pinMode(PIR_PIN, INPUT);
  pinMode(LDR_PIN, INPUT);

  // PHASE 1: SENSOR READING & PROCESSING
  unsigned long t_sensors_start = micros();
  int motionStatus = digitalRead(PIR_PIN);
  int rawLuminosity = analogRead(LDR_PIN); 

  // LUX CONVERSION
  float voltage = rawLuminosity / 4095.0 * 3.3;
  if (voltage >= 3.3) voltage = 3.299;
  float resistance = 10000 * voltage / (3.3 - voltage);
  int luminosityLux = pow(RL10 * 1e3 * pow(10, GAMMA) / resistance, (1 / GAMMA));
  
  unsigned long t_sensors_end = micros();

  // Format the data string
  String message = "";
  if (motionStatus == HIGH) {
    message = "MOTION_DETECTED-LUMINOSITY:" + String(luminosityLux);
  } else {
    message = "MOTION_NOT_DETECTED-LUMINOSITY:" + String(luminosityLux);
  }

  // PHASE 2: WI-FI AND ESP-NOW INITIALIZATION
  unsigned long t_wifi_start = micros();
  WiFi.mode(WIFI_STA);
  
  if (esp_now_init() != ESP_OK) { 
    return; 
  }
  
  // Register the peer (SINK node)
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0;  
  peerInfo.encrypt = false;
  
  if (esp_now_add_peer(&peerInfo) != ESP_OK) { 
    return; 
  }
  unsigned long t_wifi_end = micros();

  // PHASE 3: ESP-NOW TRANSMISSION
  unsigned long t_tx_start = micros();
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *)message.c_str(), message.length());
  unsigned long t_tx_end = micros();

  // Record the end of the active phase
  unsigned long time_end_active = micros();
  // END TIMING MEASUREMENTS

  // Print the results for energy consumption calculation
  Serial.println("EXECUTION TIMES (in microseconds)");
  Serial.print("Sensor Reading Duration: "); Serial.println(t_sensors_end - t_sensors_start);
  Serial.print("Wi-Fi Setup Duration: "); Serial.println(t_wifi_end - t_wifi_start);
  Serial.print("TX Transmission Duration: "); Serial.println(t_tx_end - t_tx_start);
  Serial.print("Total Active Time (Logic): "); Serial.println(time_end_active - time_start_active);
  Serial.println("---------------------------------------------");

  // Enter Deep Sleep
  Serial.flush(); // Ensure all serial data is printed before sleeping
  esp_sleep_enable_timer_wakeup(TIME_TO_SLEEP);
  esp_deep_sleep_start();
}

void loop() {
  // The loop is left empty because the ESP32 restarts from setup() 
  // every time it wakes up from Deep Sleep.
}